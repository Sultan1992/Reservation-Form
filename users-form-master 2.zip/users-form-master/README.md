#reservation form.
This code is created as sample  for users registration for reservation in Cosmopolitan Hotel of Las vegas. I used This hotel as sample. Its not real cosmopolitan website..
The usee can reserve will intend to know what vegas looks like from the site some how.
